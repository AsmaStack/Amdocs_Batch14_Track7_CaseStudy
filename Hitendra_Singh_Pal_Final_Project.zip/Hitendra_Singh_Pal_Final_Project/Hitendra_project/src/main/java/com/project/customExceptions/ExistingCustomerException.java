package com.project.customExceptions;

public class ExistingCustomerException extends Exception{

		// TODO Auto-generated constructor stub
	public ExistingCustomerException()
	{
		System.out.println();
	}
}
