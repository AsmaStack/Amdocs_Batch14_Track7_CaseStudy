package com.project.customExceptions;

public class OrderNotExistingException extends Exception{

		public OrderNotExistingException()
		{
			System.out.println();
		}
}
