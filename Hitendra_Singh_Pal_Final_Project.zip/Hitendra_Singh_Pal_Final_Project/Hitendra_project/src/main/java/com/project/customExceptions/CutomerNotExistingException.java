package com.project.customExceptions;

public class CutomerNotExistingException extends Exception{

	public CutomerNotExistingException() {
		System.out.println();
	}
	
	
}
