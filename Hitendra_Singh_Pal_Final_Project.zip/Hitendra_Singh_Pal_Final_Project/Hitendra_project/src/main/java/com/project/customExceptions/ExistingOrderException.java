package com.project.customExceptions;

public class ExistingOrderException {

	public ExistingOrderException()
	{
		
	}
	
}
